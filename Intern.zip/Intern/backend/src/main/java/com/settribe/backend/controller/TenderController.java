package com.settribe.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.settribe.backend.model.Tender;
import com.settribe.backend.service.TenderService;
import java.io.ByteArrayInputStream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;


@RestController
@RequestMapping("/api/tender")
@CrossOrigin
public class TenderController {

    @Autowired
    private TenderService tenderService;

    @PostMapping("/add")
    public Tender add(@RequestBody Tender tender) {
        return tenderService.add(tender);
    }

    @GetMapping("/all")
    public List<Tender> all() {
        return tenderService.getAll();
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        tenderService.delete(id);
        return "Deleted";
    } 
        @GetMapping("/{id}")
        public Tender getById(@PathVariable Long id) {
            return tenderService.getAll()
                    .stream()
                    .filter(t -> t.getId().equals(id))
                    .findFirst()
                    .orElse(null);
        }      
            @PutMapping("/update/{id}")
            public Tender update(@PathVariable Long id,
                                 @RequestBody Tender tender) {
                return tenderService.update(id, tender);
            }

        
@GetMapping("/export")
public ResponseEntity<byte[]> exportExcel() {

    ByteArrayInputStream in = tenderService.exportExcel();

    return ResponseEntity.ok()
        .header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=tenders.xlsx")
        .contentType(MediaType.APPLICATION_OCTET_STREAM)
        .body(in.readAllBytes());
}

/*@PostMapping("/upload")
public String uploadFiles(
        @RequestParam("photo") MultipartFile photo,
        @RequestParam("aadhar") MultipartFile aadhar,
        @RequestParam("pan") MultipartFile pan) {

    if (photo.isEmpty() || aadhar.isEmpty() || pan.isEmpty()) {
        return "All files are required";
    }

    return "Files uploaded successfully";*/


@PostMapping(
	    value = "/upload",
	    consumes = MediaType.MULTIPART_FORM_DATA_VALUE
	)
	public String uploadFiles(
	        @RequestParam("photo") MultipartFile photo,
	        @RequestParam("aadhar") MultipartFile aadhar,
	        @RequestParam("pan") MultipartFile pan
	) {

	    if (photo.isEmpty() || aadhar.isEmpty() || pan.isEmpty()) {
	        return "All files are required";
	    }

	    return "Files uploaded successfully";
	}
}




    

