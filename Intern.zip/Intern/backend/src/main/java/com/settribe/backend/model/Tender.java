package com.settribe.backend.model;

public class Tender {

    private Long id;

    private String type;          // Broker / Purchaser / Wholesaler
    private String fullName;

    private String address;
    private String city;
    private String district;
    private String state;
    private String pincode;

    private String mobile;
    private String email;

    private String license;       // YES / NO
    private String gst;           // YES / NO

    private String goodsType;
    private String goodsDemand;
    private String ratePerQuantity;

    private String remarks;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLicense() {
		return license;
	}

	public void setLicense(String license) {
		this.license = license;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public String getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(String goodsType) {
		this.goodsType = goodsType;
	}

	public String getGoodsDemand() {
		return goodsDemand;
	}

	public void setGoodsDemand(String goodsDemand) {
		this.goodsDemand = goodsDemand;
	}

	public String getRatePerQuantity() {
		return ratePerQuantity;
	}

	public void setRatePerQuantity(String ratePerQuantity) {
		this.ratePerQuantity = ratePerQuantity;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

    // getters & setters (auto-generate)
    
}
