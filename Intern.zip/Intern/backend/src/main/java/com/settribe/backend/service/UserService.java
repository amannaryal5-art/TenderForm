package com.settribe.backend.service;

import org.springframework.stereotype.Service;
import com.settribe.backend.model.User;
import com.settribe.backend.storage.InMemoryDB;

import java.util.List;
//import com.settribe.backend.storage.InMemoryDB;


@Service
public class UserService {

    // REGISTER USER
    public User register(User user) {
        user.setId(InMemoryDB.userId.getAndIncrement());
        user.setFullName(
            user.getFirstName() + " " +
            user.getMiddleName() + " " +
            user.getLastName()
        );
        InMemoryDB.users.add(user);
        return user;
    }

    // LOGIN USER
    public User login(String email, String password) {
        return InMemoryDB.users.stream()
            .filter(u -> u.getEmail().equals(email)
                      && u.getPassword().equals(password))
            .findFirst()
            .orElse(null);
    }


public List<User> getAllUsers() {
    return InMemoryDB.users;
}
}