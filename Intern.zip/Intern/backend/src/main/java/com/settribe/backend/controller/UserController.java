package com.settribe.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.settribe.backend.model.User;
import com.settribe.backend.service.UserService;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {

    @Autowired
    private UserService userService;

    // REGISTER API
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.register(user);
    }

    // LOGIN API
    @PostMapping("/login")
    public Object login(@RequestBody User user) {

        User loggedInUser =
            userService.login(user.getEmail(), user.getPassword());

        if (loggedInUser == null) {
            return "Invalid email or password";
        }
        return loggedInUser;
    }

@GetMapping("/captcha")
public String getCaptcha() {
    int captcha = (int)(Math.random() * 9000) + 1000;
    return String.valueOf(captcha);
}

@PostMapping("/login-with-captcha")
public String loginWithCaptcha(
        @RequestParam String email,
        @RequestParam String password,
        @RequestParam String captcha,
        @RequestParam String actualCaptcha) {

    if (!captcha.equals(actualCaptcha)) {
        return "Invalid Captcha";
    }

    User user = userService.login(email, password);
    return user != null ? "Login Successful" : "Invalid Credentials";
}

@GetMapping("/all")
public Object getAllUsers() {
    return userService.getAllUsers();
}
}