package com.settribe.backend.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.settribe.backend.model.Tender;
import com.settribe.backend.storage.InMemoryDB;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


@Service
public class TenderService {

    // ADD TENDER
    public Tender add(Tender tender) {
        tender.setId(InMemoryDB.tenderId.getAndIncrement());
        InMemoryDB.tenders.add(tender);
        return tender;
    }

    // REPORT
    public List<Tender> getAll() {
        return InMemoryDB.tenders;
    }

    // DELETE
    public void delete(Long id) {
        InMemoryDB.tenders.removeIf(t -> t.getId().equals(id));
    }

//UPDATE TENDER
public Tender update(Long id, Tender updatedTender) {

 for (Tender t : InMemoryDB.tenders) {
     if (t.getId().equals(id)) {

         t.setType(updatedTender.getType());
         t.setFullName(updatedTender.getFullName());
         t.setAddress(updatedTender.getAddress());
         t.setCity(updatedTender.getCity());
         t.setDistrict(updatedTender.getDistrict());
         t.setState(updatedTender.getState());
         t.setPincode(updatedTender.getPincode());
         t.setMobile(updatedTender.getMobile());
         t.setEmail(updatedTender.getEmail());
         t.setLicense(updatedTender.getLicense());
         t.setGst(updatedTender.getGst());
         t.setGoodsType(updatedTender.getGoodsType());
         t.setGoodsDemand(updatedTender.getGoodsDemand());
         t.setRatePerQuantity(updatedTender.getRatePerQuantity());
         t.setRemarks(updatedTender.getRemarks());

         return t;
     }
 }
 return null;
}

public ByteArrayInputStream exportExcel() {

    try (Workbook workbook = new XSSFWorkbook()) {

        Sheet sheet = workbook.createSheet("Tenders");

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("ID");
        header.createCell(1).setCellValue("Type");
        header.createCell(2).setCellValue("Full Name");
        header.createCell(3).setCellValue("Mobile");
        header.createCell(4).setCellValue("Goods Type");
        header.createCell(5).setCellValue("Goods Demand");

        int rowIdx = 1;
        for (var t : InMemoryDB.tenders) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(t.getId());
            row.createCell(1).setCellValue(t.getType());
            row.createCell(2).setCellValue(t.getFullName());
            row.createCell(3).setCellValue(t.getMobile());
            row.createCell(4).setCellValue(t.getGoodsType());
            row.createCell(5).setCellValue(t.getGoodsDemand());
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        workbook.write(out);
        return new ByteArrayInputStream(out.toByteArray());

    } catch (Exception e) {
        return null;
    }
}}



