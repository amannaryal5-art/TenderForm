package com.settribe.backend.storage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.settribe.backend.model.User;
import com.settribe.backend.model.Tender;

public class InMemoryDB {

    public static List<User> users = new ArrayList<>();
    public static AtomicLong userId = new AtomicLong(1);
    
    

 // ADD THESE BELOW USER STORAGE
 public static List<Tender> tenders = new ArrayList<>();
 public static AtomicLong tenderId = new AtomicLong(1);

}
